Directorio por defecto para guardar el código fuente de las tácticas
